@extends('layout.erp.home')
@section('page')
<div class="col-lg-12 stretch-card">
              <div class="card">
                <div class="card-body">
                  <!-- <h4 class="card-title">Table with contextual classes</h4>
                  <p class="card-description">
                    Add class <code>.table-{color}</code>
                  </p> -->
                  <div class="table-responsive">
                      <div>
                          <h3><a href="{{route('orders.create')}}">New Order</a></h3>
                      </div>
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>
                           ID
                          </th>
                          <th>
                            Customer Name
                          </th>
                          <th>
                            Service
                          </th>
                          <th>
                            Price
                          </th>
                         
                          <th>
                            Action
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                          @forelse($orders as $order)
                        <tr class="table-info">
                          <td>
                            {{$order->id}}
                          </td>
                          <td>
                          {{$order->customer_name}}
                          </td>
                          <td>
                          {{$order->service}}
                          </td>
                          <td>
                          {{$order->price}}
                          </td>
                        
                         
                          <td>
                          <div style="display:flex">
                                <a  class="btn btn-outline-primary" href="{{route('orders.edit',$order->id)}}">Edit<a>  
                                <!-- <a style="flex:1 1 0" class="btn btn-outline-success" href="{{route('orders.show',$order->id)}}">Details<a>  -->


                                <form action="{{route('orders.destroy',$order->id)}}" method="post" style='float:left'>
                                    @csrf
                                    @method("DELETE")            
                                    <input type="submit" name="btnDelete" value="Delete" class="btn btn-outline-danger" />
</form>
                        </div>
                          </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="3">

                            </td>
                        </tr>
                       @endforelse
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

            @endsection