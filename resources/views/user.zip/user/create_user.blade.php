<!-- <form action="{{url('user/save')}}" method="post"> -->
<form action="{{route('users.store')}}" method="post">
    @csrf
    <input type="text" name="txtName" />
    <input type="submit" name="btnCreate" value="Create" />
</form>

