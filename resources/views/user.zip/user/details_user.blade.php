<h1>Only One record</h1>
{{$id}}