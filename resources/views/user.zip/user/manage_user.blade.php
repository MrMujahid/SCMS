<h1>Manage User</h1>
<table>
<tr>
    <th>Name</th>
    <th>Email</th>
    <th>Action</th>
</tr>
<tr>
    <td>
      Jahidul Islam
    </td>
    <td>
     jahid@yahoo.com
    </td>
    <td>
        <div style="display:flex">
            <a style="flex:1 1 0" href="{{route('users.edit',1)}}">Edit<a>&nbsp; 
            <a style="flex:1 1 0" href="{{route('users.show',1)}}">Details<a>
            <form style="flex:1 1 0" action="{{route('users.destroy',1)}}" method="post">
                @csrf
                @method("DELETE")            
                <input type="submit" name="btnDelete" value="Delete" />
            </form>
       </div>
    </td>
</tr>
<tr>
    <td>
      Neyamot Ullha
    </td>
    <td>
     neyamot@yahoo.com
    </td>
    <td>
        <div style="display:flex">
            <a style="flex:1 1 0" href="{{route('users.edit',2)}}">Edit<a> 
            <a style="flex:1 1 0"  href="{{route('users.show',2)}}">Details<a> 
            <form style="flex:1 1 0" action="{{route('users.destroy',2)}}" method="post">
                @csrf
                @method("DELETE")            
                <input type="submit" name="btnDelete" value="Delete"  />
            </form>
        </div>  
    </td>
</tr>
<tr>
    <td>
      Tanvir
    </td>
    <td>
     tanvir@yahoo.com
    </td>
    <td>
        <div style="display:flex">
            <a style="flex:1 1 0" href="{{route('users.edit',3)}}">Edit<a>  
            <a style="flex:1 1 0" href="{{route('users.show',3)}}">Details<a> 
            <form style="flex:1 1 0" action="{{route('users.destroy',3)}}" method="post" style='float:left'>
                @csrf
                @method("DELETE")            
                <input type="submit" name="btnDelete" value="Delete" />
            </form>
      </div>
    </td>
</tr>
</table>