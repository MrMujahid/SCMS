Record No: {{$id}}

<form action="{{route('users.update',$id)}}" method="post">
    @csrf
    @method("PUT")
    <input type="hidden" name="txtId" value="{{$id}}" />
    Name :<input type="text" name="txtName" value="" />
    <input type="submit" name="btnSubmit" value="Update" />
</form>

